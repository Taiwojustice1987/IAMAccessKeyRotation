import boto3
import csv
import io
from datetime import datetime, timezone

# ========== CONFIGURABLE VARIABLES ==========
ACCOUNT_ROLES = [
    "arn:aws:iam::135808961729:role/IAMKeyRotationRole",
    "arn:aws:iam::767397775487:role/IAMKeyRotationRole"
]

BUCKET_NAME = "key-rotation-reports-central"
SNS_TOPIC_ARN = "arn:aws:sns:us-east-1:626635400294:IAMKeyRotationNotifications"
ROTATION_DAYS = 2
# ===========================================

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    sns = boto3.client('sns')
    rotated_keys = []
    now = datetime.now(timezone.utc)

    for role_arn in ACCOUNT_ROLES:
        sts = boto3.client('sts')

        try:
            # Assume the IAMKeyRotationRole in each account
            creds = sts.assume_role(
                RoleArn=role_arn,
                RoleSessionName='RotateKeysSession'
            )['Credentials']

            iam = boto3.client(
                'iam',
                aws_access_key_id=creds['AccessKeyId'],
                aws_secret_access_key=creds['SecretAccessKey'],
                aws_session_token=creds['SessionToken']
            )

            users = iam.list_users()['Users']
            for user in users:
                username = user['UserName']
                keys = iam.list_access_keys(UserName=username)['AccessKeyMetadata']

                for key in keys:
                    age_days = (now - key['CreateDate']).days
                    if age_days > ROTATION_DAYS:

                        # 🟢 New logic: Check if user already has 2 keys
                        if len(keys) >= 2:
                            # Sort by creation date and delete the oldest one
                            oldest_key = sorted(keys, key=lambda k: k['CreateDate'])[0]
                            iam.delete_access_key(UserName=username, AccessKeyId=oldest_key['AccessKeyId'])
                            print(f"Deleted oldest key {oldest_key['AccessKeyId']} for user {username}")

                        # 🟢 Now create the new key safely
                        new_key = iam.create_access_key(UserName=username)['AccessKey']

                        # Deactivate and delete old key
                        iam.update_access_key(
                            UserName=username,
                            AccessKeyId=key['AccessKeyId'],
                            Status='Inactive'
                        )
                        iam.delete_access_key(
                            UserName=username,
                            AccessKeyId=key['AccessKeyId']
                        )

                        rotated_keys.append({
                            "AccountRole": role_arn,
                            "User": username,
                            "OldKey": key['AccessKeyId'],
                            "NewKey": new_key['AccessKeyId'],
                            "AgeDays": age_days
                        })

        except Exception as e:
            print(f"Error processing {role_arn}: {e}")

    # Create CSV in memory
    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=["AccountRole", "User", "OldKey", "NewKey", "AgeDays"])
    writer.writeheader()
    writer.writerows(rotated_keys)

    # Upload report to S3
    report_name = f"rotated_keys_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.csv"
    s3.put_object(
        Bucket=BUCKET_NAME,
        Key=report_name,
        Body=csv_buffer.getvalue()
    )

    # Send SNS notification
    message = (
        f"IAM access key rotation completed.\n\n"
        f"Report saved in S3 bucket: {BUCKET_NAME}/{report_name}\n"
        f"Total keys rotated: {len(rotated_keys)}"
    )

    try:
        sns.publish(
            TopicArn=SNS_TOPIC_ARN,
            Message=message,
            Subject="IAM Access Key Rotation Summary"
        )
    except Exception as e:
        print(f"Error sending SNS notification: {e}")

    return {
        "status": "done",
        "rotated_count": len(rotated_keys),
        "report": report_name
    }
